const {
  createHash,
  randomBytes,
  randomInt,
  timingSafeEqual,
} = require("crypto");
const nodemailer = require("nodemailer");

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const OTP_TTL_MS = 5 * 60 * 1000;
const RESEND_COOLDOWN_MS = 30 * 1000;
const CHALLENGE_WINDOW_MS = 15 * 60 * 1000;
const EMAIL_SEND_LIMIT = 5;
const IP_SEND_LIMIT = 20;
const OTP_ATTEMPT_LIMIT = 5;

const challenges = new Map();
const emailSendWindows = new Map();
const ipSendWindows = new Map();

function hashOtp(challengeId, otp) {
  return createHash("sha256").update(`${challengeId}:${otp}`).digest();
}

function isOtpMatch(challenge, otp) {
  const submittedHash = hashOtp(challenge.id, otp);
  return (
    challenge.otpHash?.length === submittedHash.length &&
    timingSafeEqual(challenge.otpHash, submittedHash)
  );
}

function getSmtpConfig() {
  const required = [
    "SMTP_HOST",
    "SMTP_PORT",
    "SMTP_SECURE",
    "SMTP_USER",
    "SMTP_PASS",
    "SMTP_FROM",
  ];
  console.log("SMTP ENV CHECK:", {
  SMTP_HOST: !!process.env.SMTP_HOST,
  SMTP_PORT: !!process.env.SMTP_PORT,
  SMTP_SECURE: !!process.env.SMTP_SECURE,
  SMTP_USER: !!process.env.SMTP_USER,
  SMTP_PASS: !!process.env.SMTP_PASS,
  SMTP_FROM: !!process.env.SMTP_FROM,
});
  const missing = required.filter(
    (name) => typeof process.env[name] !== "string" || !process.env[name].trim(),
  );

  if (missing.length) {
    return { missing };
  }

  const port = Number(process.env.SMTP_PORT);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    return { invalid: "SMTP_PORT must be a valid port number." };
  }
  const secure = process.env.SMTP_SECURE.trim().toLowerCase();
  if (secure !== "true" && secure !== "false") {
    return { invalid: "SMTP_SECURE must be either true or false." };
  }

  return {
    config: {
      host: process.env.SMTP_HOST.trim(),
      port,
      secure: secure === "true",
      auth: {
        user: process.env.SMTP_USER.trim(),
        pass: process.env.SMTP_PASS,
      },
      connectionTimeout: 10000,
      greetingTimeout: 10000,
      socketTimeout: 15000,
    },
  };
}

function takeWindow(map, key, limit, now, windowMs) {
  let window = map.get(key);
  if (!window || window.resetAt <= now) {
    window = { count: 0, resetAt: now + windowMs };
    map.set(key, window);
  }

  if (window.count >= limit) {
    return Math.max(1, Math.ceil((window.resetAt - now) / 1000));
  }

  window.count += 1;
  return 0;
}

function cleanup(now) {
  for (const [id, challenge] of challenges) {
    if (challenge.createdAt + CHALLENGE_WINDOW_MS <= now) {
      challenges.delete(id);
    }
  }
  for (const [key, window] of emailSendWindows) {
    if (window.resetAt <= now) emailSendWindows.delete(key);
  }
  for (const [key, window] of ipSendWindows) {
    if (window.resetAt <= now) ipSendWindows.delete(key);
  }
}

function getRequestEmail(req, res) {
  const email =
    typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
  if (!EMAIL_PATTERN.test(email) || email.length > 254) {
    res.status(400).json({
      success: false,
      message: "Enter a valid email address.",
    });
    return null;
  }
  return email;
}

function getProductKey(req, res) {
  const productKey =
    typeof req.body?.productKey === "string" ? req.body.productKey.trim() : "";
  if (!productKey || productKey.length > 200) {
    res.status(400).json({
      success: false,
      message: "A valid product is required for brochure access.",
    });
    return null;
  }
  return productKey;
}

function getOtp(req, res) {
  const otp = typeof req.body?.otp === "string" ? req.body.otp.trim() : "";
  if (!/^\d{6}$/.test(otp)) {
    res.status(400).json({
      success: false,
      message: "Enter the 6-digit OTP sent to your email.",
    });
    return null;
  }
  return otp;
}

async function deliverOtp(email, otp, smtpConfig) {
  const transporter = nodemailer.createTransport(smtpConfig);
  await transporter.sendMail({
    from: process.env.SMTP_FROM.trim(),
    to: email,
    subject: "Your Boiler House brochure access code",
    text: `Your one-time password is ${otp}. It expires in 5 minutes. Do not share this code with anyone.`,
    html: `<p>Your one-time password is <strong>${otp}</strong>.</p><p>It expires in 5 minutes. Do not share this code with anyone.</p>`,
  });
}

function requireSmtp(res) {
  const result = getSmtpConfig();
  if (result.missing) {
    res.status(503).json({
      success: false,
      message: `Email OTP is not configured. Set these backend environment variables: ${result.missing.join(", ")}.`,
    });
    return null;
  }
  if (result.invalid) {
    res.status(503).json({ success: false, message: result.invalid });
    return null;
  }
  return result.config;
}

async function sendOtp(req, res) {
  const email = getRequestEmail(req, res);
  if (!email) return;
  const productKey = getProductKey(req, res);
  if (!productKey) return;
  const smtpConfig = requireSmtp(res);
  if (!smtpConfig) return;

  const now = Date.now();
  cleanup(now);
  const emailWait = takeWindow(
    emailSendWindows,
    email,
    EMAIL_SEND_LIMIT,
    now,
    CHALLENGE_WINDOW_MS,
  );
  const ipWait = takeWindow(
    ipSendWindows,
    req.ip || "unknown",
    IP_SEND_LIMIT,
    now,
    60 * 60 * 1000,
  );
  if (emailWait || ipWait) {
    return res.status(429).json({
      success: false,
      message: "Too many OTP requests. Please try again later.",
      retryAfterSeconds: Math.max(emailWait, ipWait),
    });
  }

  const id = randomBytes(32).toString("hex");
  const otp = String(randomInt(0, 1000000)).padStart(6, "0");

  try {
    await deliverOtp(email, otp, smtpConfig);
  } catch (error) {
    console.error("Brochure OTP email delivery failed:", error.message);
    return res.status(502).json({
      success: false,
      message: "We could not send the OTP email. Please try again later.",
    });
  }

  challenges.set(id, {
    id,
    email,
    productKey,
    otpHash: hashOtp(id, otp),
    createdAt: now,
    expiresAt: now + OTP_TTL_MS,
    lastSentAt: now,
    attempts: 0,
    verified: false,
  });

  return res.status(200).json({
    success: true,
    challengeId: id,
    expiresInSeconds: OTP_TTL_MS / 1000,
    resendAfterSeconds: RESEND_COOLDOWN_MS / 1000,
  });
}

async function resendOtp(req, res) {
  const challengeId =
    typeof req.body?.challengeId === "string" ? req.body.challengeId : "";
  const challenge = challenges.get(challengeId);
  if (!challenge) {
    return res.status(400).json({
      success: false,
      message: "This OTP request has expired. Start again to request a new code.",
    });
  }

  const smtpConfig = requireSmtp(res);
  if (!smtpConfig) return;
  const now = Date.now();
  cleanup(now);

  if (challenge.verified || challenge.attempts >= OTP_ATTEMPT_LIMIT) {
    return res.status(429).json({
      success: false,
      message: "This OTP request can no longer be used. Start again.",
    });
  }
  if (challenge.createdAt + CHALLENGE_WINDOW_MS <= now) {
    challenges.delete(challengeId);
    return res.status(400).json({
      success: false,
      message: "This OTP request has expired. Start again to request a new code.",
    });
  }
  if (now - challenge.lastSentAt < RESEND_COOLDOWN_MS) {
    return res.status(429).json({
      success: false,
      message: "Please wait before requesting another OTP.",
      retryAfterSeconds: Math.ceil(
        (RESEND_COOLDOWN_MS - (now - challenge.lastSentAt)) / 1000,
      ),
    });
  }

  const emailWait = takeWindow(
    emailSendWindows,
    challenge.email,
    EMAIL_SEND_LIMIT,
    now,
    CHALLENGE_WINDOW_MS,
  );
  const ipWait = takeWindow(
    ipSendWindows,
    req.ip || "unknown",
    IP_SEND_LIMIT,
    now,
    60 * 60 * 1000,
  );
  if (emailWait || ipWait) {
    return res.status(429).json({
      success: false,
      message: "Too many OTP requests. Please try again later.",
      retryAfterSeconds: Math.max(emailWait, ipWait),
    });
  }

  const otp = String(randomInt(0, 1000000)).padStart(6, "0");
  try {
    await deliverOtp(challenge.email, otp, smtpConfig);
  } catch (error) {
    console.error("Brochure OTP email delivery failed:", error.message);
    return res.status(502).json({
      success: false,
      message: "We could not send the OTP email. Please try again later.",
    });
  }

  challenge.otpHash = hashOtp(challengeId, otp);
  challenge.expiresAt = now + OTP_TTL_MS;
  challenge.lastSentAt = now;

  return res.status(200).json({
    success: true,
    expiresInSeconds: OTP_TTL_MS / 1000,
    resendAfterSeconds: RESEND_COOLDOWN_MS / 1000,
  });
}

function verifyOtp(req, res) {
  const challengeId =
    typeof req.body?.challengeId === "string" ? req.body.challengeId : "";
  const challenge = challenges.get(challengeId);
  if (!challenge) {
    return res.status(400).json({
      success: false,
      message: "This OTP request has expired. Start again to request a new code.",
    });
  }

  const productKey = getProductKey(req, res);
  if (!productKey) return;
  if (productKey !== challenge.productKey) {
    return res.status(400).json({
      success: false,
      message: "This OTP was requested for a different product. Start again.",
    });
  }
  if (challenge.verified) {
    return res.status(400).json({
      success: false,
      message: "This OTP has already been used. Start again to request a new code.",
    });
  }
  if (Date.now() >= challenge.expiresAt) {
    return res.status(400).json({
      success: false,
      message: "This OTP has expired. Request a new code.",
    });
  }
  if (challenge.attempts >= OTP_ATTEMPT_LIMIT) {
    return res.status(429).json({
      success: false,
      message: "Too many incorrect attempts. Start again to request a new code.",
    });
  }

  const otp = getOtp(req, res);
  if (!otp) return;
  challenge.attempts += 1;

  if (!isOtpMatch(challenge, otp)) {
    return res.status(400).json({
      success: false,
      message:
        challenge.attempts >= OTP_ATTEMPT_LIMIT
          ? "Too many incorrect attempts. Start again to request a new code."
          : "The OTP is incorrect. Please check the code and try again.",
    });
  }

  challenge.verified = true;
  challenge.otpHash = null;
  return res.status(200).json({
    success: true,
    verified: true,
  });
}

module.exports = {
  sendOtp,
  resendOtp,
  verifyOtp,
};
