import { Link } from "react-router-dom";
import { ArrowRightIcon, PackageIcon } from "./Icons.jsx";

/**
 * Category tile for the All Categories page. The whole card, including the
 * image and the category name, is a link to the existing category route that
 * lists that category's products.
 */
export default function CategoryCard({ category, count }) {
  const hasCount = typeof count === "number";

  return (
    <article className="category-card group h-full border border-line bg-white">
      <Link
        to={`/products/${category.slug}`}
        className="flex h-full flex-col"
        aria-label={`View ${category.name} products`}
      >
        <div className="relative overflow-hidden border-b border-line bg-white">
          <div className="flex aspect-square items-center justify-center p-4 sm:p-5">
            {category.image ? (
              <img
                src={category.image}
                alt={category.name}
                width="1000"
                height="1000"
                loading="lazy"
                decoding="async"
                className="category-card-image h-full w-full object-contain"
              />
            ) : (
              <div className="flex h-full w-full flex-col items-center justify-center gap-3 text-slate-400">
                <PackageIcon className="h-12 w-12" />
                <span className="text-[10px] font-semibold uppercase tracking-[0.2em]">
                  Category image
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-1 flex-col px-4 py-4 sm:px-5 sm:py-5">
          <h3 className="category-card-title min-h-[3.5rem] font-display text-[1.15rem] font-semibold uppercase leading-[1.08] tracking-[0.03em] text-ink sm:text-[1.3rem] lg:min-h-[3.9rem] lg:text-[1.35rem]">
            {category.name}
          </h3>

          <div className="mt-auto flex flex-wrap items-center justify-between gap-x-3 gap-y-2 pt-4">
            <span className="inline-flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.16em] text-brand">
              View products
              <ArrowRightIcon className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
            </span>

            {hasCount ? (
              <span className="whitespace-nowrap border border-line bg-paper px-2 py-1 text-[9px] font-bold uppercase tracking-[0.12em] text-steel">
                {count} {count === 1 ? "Item" : "Items"}
              </span>
            ) : null}
          </div>
        </div>
      </Link>
    </article>
  );
}
