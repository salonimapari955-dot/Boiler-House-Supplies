import { Link } from "react-router-dom";
import Reveal from "./Reveal.jsx";
import { BricksIcon, GaugeIcon, GrateIcon, ValveIcon } from "./Icons.jsx";

const services = [
  {
    title: "Boiler Mountings",
    description:
      "Safety valves, pressure gauges and water level indicators for boiler house assemblies.",
    icon: GaugeIcon,
    accent: "#b4471f",
    to: "/products",
  },
  {
    title: "Castings & Grate Parts",
    description:
      "Boiler castings, grate bars and fire bars built for demanding operating conditions.",
    icon: GrateIcon,
    accent: "#3b6478",
    to: "/products",
  },
  {
    title: "Industrial Valves",
    description:
      "Steam, feed water and process valves suited to industrial pressure and temperature.",
    icon: ValveIcon,
    accent: "#a06a1f",
    to: "/products",
  },
  {
    title: "Refractory Products",
    description:
      "Fire bricks, castables and insulation for boiler linings and heat containment.",
    icon: BricksIcon,
    accent: "#9c3f2f",
    to: "/products",
  },
];

const BOLT_ANGLES = [0, 45, 90, 135, 180, 225, 270, 315];
const DIAL_TICKS = Array.from({ length: 25 }, (_, index) => index * 15);

function polar(cx, cy, radius, angle) {
  const radians = (angle * Math.PI) / 180;

  return {
    x: cx + Math.cos(radians) * radius,
    y: cy + Math.sin(radians) * radius,
  };
}

/**
 * Faint blueprint-style line work behind the services sheet. Everything is
 * drawn with SVG strokes — no bitmap or CSS background image is used.
 */
function ServicesPattern() {
  return (
    <div
      className="services-backdrop pointer-events-none absolute inset-0 overflow-hidden text-[#4a5560]"
      aria-hidden="true"
    >
      <svg
        className="absolute inset-0 h-full w-full"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
        focusable="false"
      >
        <defs>
          <pattern
            id="services-grid-lines"
            width="96"
            height="96"
            patternUnits="userSpaceOnUse"
          >
            <path d="M96 0H0v96" opacity="0.4" />
          </pattern>

          <pattern
            id="services-technical-lines"
            width="280"
            height="280"
            patternUnits="userSpaceOnUse"
          >
            <path d="M140 126v28M126 140h28" opacity="0.55" />
            <circle cx="52" cy="52" r="18" opacity="0.6" />
            <circle cx="52" cy="52" r="7" opacity="0.45" />
            <path d="M232 44v16M224 52h16" opacity="0.45" />
            <path
              d="m194 208 22 12-22 12zM266 208l-22 12 22 12zM216 220h28"
              opacity="0.5"
            />
            <path d="M244 220v-18M232 202h24" opacity="0.45" />
            <path d="M34 236h66" opacity="0.4" />
            <path d="M34 228v16M100 228v16" opacity="0.4" />
            <path d="M0 280 24 256M280 24 256 0" opacity="0.28" />
          </pattern>
        </defs>

        <rect width="100%" height="100%" fill="url(#services-grid-lines)" />
        <rect
          width="100%"
          height="100%"
          fill="url(#services-technical-lines)"
        />
      </svg>

      {/* Large flange / boiler-end drawing, left. */}
      <svg
        className="absolute -left-28 -top-10 hidden h-[430px] w-[430px] lg:block"
        viewBox="0 0 430 430"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
        focusable="false"
      >
        <g opacity="0.85">
          <circle cx="215" cy="215" r="160" />
          <circle cx="215" cy="215" r="132" />
          <circle cx="215" cy="215" r="76" />
          <circle cx="215" cy="215" r="14" />
          {BOLT_ANGLES.map((angle) => {
            const bolt = polar(215, 215, 146, angle);
            const inner = polar(215, 215, 76, angle);

            return (
              <g key={`flange-bolt-${angle}`}>
                <circle cx={bolt.x} cy={bolt.y} r="6" />
                <path
                  d={`M${inner.x} ${inner.y}L${bolt.x} ${bolt.y}`}
                  opacity="0.45"
                />
              </g>
            );
          })}
          <path
            d="M20 215h54M362 215h48M215 82V28M215 348v54"
            opacity="0.6"
          />
        </g>
      </svg>

      {/* Dial gauge drawing, right. */}
      <svg
        className="absolute -right-24 top-16 hidden h-[360px] w-[360px] lg:block"
        viewBox="0 0 360 360"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
        focusable="false"
      >
        <g opacity="0.85">
          <circle cx="180" cy="180" r="142" />
          <circle cx="180" cy="180" r="126" opacity="0.55" />
          <circle cx="180" cy="180" r="104" />
          <circle cx="180" cy="180" r="7" />
          {DIAL_TICKS.map((angle) => {
            const outer = polar(180, 180, 142, angle);
            const inner = polar(180, 180, angle % 45 === 0 ? 118 : 128, angle);

            return (
              <path
                key={`dial-tick-${angle}`}
                d={`M${inner.x} ${inner.y}L${outer.x} ${outer.y}`}
                opacity="0.7"
              />
            );
          })}
          <path d="M180 173V96" opacity="0.75" />
          <path d="M180 66v14M146 74l7 12M214 74l-7 12" opacity="0.6" />
          <path
            d="M10 180h28M322 180h28M180 10v28M180 322v28"
            opacity="0.55"
          />
        </g>
      </svg>
    </div>
  );
}

export default function ServicesSection() {
  return (
    <section id="services" className="services-overlap">
      <div className="services-tab">
        <div className="flex items-center justify-center gap-5 px-5 py-4 sm:gap-7 sm:px-8">
          <span className="h-px flex-1 bg-[#dcdcdc]" aria-hidden="true" />
          <p className="text-[clamp(2.5rem,4.6vw,3.5rem)] font-bold leading-[1.05] tracking-[0.01em] text-[#555555]">
            Services
          </p>
          <span className="h-px flex-1 bg-[#dcdcdc]" aria-hidden="true" />
        </div>
      </div>

      <div className="services-sheet pb-12 pt-14 sm:pt-16 lg:pb-14 lg:pt-20">
        <span
          className="pointer-events-none absolute inset-x-0 top-0 h-px bg-[#e2e2e2]"
          aria-hidden="true"
        />

        <ServicesPattern />

        <div className="relative z-10 mx-auto max-w-[1180px] px-5">
          <Reveal>
            <div className="text-center">
              <h2 className="mx-auto mt-2 max-w-[760px] text-[1.15rem] font-semibold leading-[1.4] text-[#555555] sm:text-[1.3rem]">
                Industrial Boiler Products &amp; Solutions
              </h2>
              <p className="mx-auto mt-2 max-w-[640px] text-[1rem] leading-[1.8] text-[#666666] sm:text-[1.125rem]">
                Boiler mountings, castings, industrial valves and refractory
                products.
              </p>
            </div>
          </Reveal>

          <div className="mt-12 grid grid-cols-1 gap-y-11 border-t border-[#e5e5e5] pt-10 sm:grid-cols-2 sm:gap-x-10 sm:gap-y-12 lg:mt-16 lg:grid-cols-4 lg:gap-x-0 lg:gap-y-0 lg:pt-14">
            {services.map((service, index) => {
              const Icon = service.icon;

              return (
                <Reveal
                  key={service.title}
                  delay={120 + index * 80}
                  className={`h-full ${
                    index > 0 ? "lg:border-l lg:border-[#e5e5e5]" : ""
                  }`}
                >
                  <Link
                    to={service.to}
                    className="flex h-full flex-col items-center px-2 text-center lg:px-8"
                  >
                    <span
                      className="flex h-24 w-24 items-center justify-center"
                      style={{ color: service.accent }}
                    >
                      <Icon className="h-24 w-24" />
                    </span>

                    <h3 className="mt-5 text-[1.1rem] font-semibold leading-[1.35] text-[#555555] sm:mt-6 sm:text-[1.25rem]">
                      {service.title}
                    </h3>

                    <p className="mt-3 max-w-[260px] text-[0.9rem] leading-[1.8] text-[#666666]">
                      {service.description}
                    </p>
                  </Link>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
